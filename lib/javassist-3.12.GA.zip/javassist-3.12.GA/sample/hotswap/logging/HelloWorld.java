public class HelloWorld {
    public void print() {
        System.out.println("** HelloWorld.print()");
        System.out.println("hello world");
    }
}
